package org.example.quarkus.notification;

import io.quarkus.arc.runtime.BeanContainer;
import io.quarkus.runtime.annotations.Recorder;
import org.example.notification.sender.Sender;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Recorder
public class SenderRecorder {

    /**
     * Регистрация списка имплементаций отправщика
     *
     * @param implementationClasses классы имплементаторы
     */
    public List<Sender> registry(Collection<Class<? extends Sender>> implementationClasses) {
        // configure our service statically
        List<Sender> services = new ArrayList<>(implementationClasses.size());
        // instantiate the service implementations
        for (Class<? extends Sender> implementationClass : implementationClasses) {
            try {
                services.add(implementationClass.getConstructor().newInstance());
            } catch (Exception e) {
//                throw new IllegalArgumentException("Unable to instantiate service " + implementationClass, e);
            }
        }

        return services;
    }

    /**
     * Отправка всеми сервисами соответствующих сообщений
     *
     * @param beanContainer контейнер бинов
     * @param services      список зарегистрированных методов
     * @param from          от кого
     * @param to            кому
     */
    public void sendAll(BeanContainer beanContainer, List<Sender> services, String from, String to) {
        services.forEach(s -> {
            Sender instance = beanContainer.instance(s.getClass());
            instance.send(from, to);
        });
    }
}
