package org.example.quarkus.notification.subst;

import io.quarkus.runtime.ObjectSubstitution;
import org.example.notification.sender.SmsSenderImpl;

/**
 * Объект заменитель
 */
public class SmsSenderImplObjectSubstitution implements ObjectSubstitution<SmsSenderImpl, SmsSenderImplObjectSubstitution.SmsSenderSubstitutionProxy> {

    @Override
    public SmsSenderSubstitutionProxy serialize(SmsSenderImpl obj) {
        SmsSenderSubstitutionProxy smsSenderSubstitutionProxy = new SmsSenderSubstitutionProxy();
        smsSenderSubstitutionProxy.setFrom(obj.getFrom());
        smsSenderSubstitutionProxy.setTo(obj.getTo());
        return smsSenderSubstitutionProxy;
    }

    @Override
    public SmsSenderImpl deserialize(SmsSenderSubstitutionProxy obj) {
        return new SmsSenderImpl(obj.getFrom(), obj.getTo());
    }

    /**
     * Реализация отправки СМС
     */
    public static class SmsSenderSubstitutionProxy extends SmsSenderImpl {

        private String from;
        private String to;

        public SmsSenderSubstitutionProxy() {
            super(null, null);
        }

        public SmsSenderSubstitutionProxy(String from, String to) {
            super(from, to);
        }

        //        Getter-Setter Block



        @Override
        public void send(String from, String to) {
            super.send(from, to);
        }

        @Override
        public void send() {
            super.send();
        }

        public String getFrom() {
            return from;
        }

        public void setFrom(String from) {
            this.from = from;
        }

        public String getTo() {
            return to;
        }

        public void setTo(String to) {
            this.to = to;
        }
    }
}
