package org.example.quarkus.notification.deployment;

import io.quarkus.arc.deployment.BeanContainerBuildItem;
import io.quarkus.deployment.annotations.BuildProducer;
import io.quarkus.deployment.annotations.BuildStep;
import io.quarkus.deployment.annotations.ExecutionTime;
import io.quarkus.deployment.annotations.Record;
import io.quarkus.deployment.builditem.FeatureBuildItem;
import io.quarkus.deployment.builditem.ObjectSubstitutionBuildItem;
import io.quarkus.deployment.recording.RecorderContext;
import io.quarkus.deployment.util.ServiceUtil;
import org.example.notification.sender.Sender;
import org.example.notification.sender.SmsSenderImpl;
import org.example.quarkus.notification.SenderRecorder;
import org.example.quarkus.notification.configuration.SendConfig;
import org.example.quarkus.notification.deployment.build.item.SpiInfoBuildItem;
import org.example.quarkus.notification.subst.SmsSenderImplObjectSubstitution;

import java.io.IOException;
import java.util.*;

import static io.quarkus.deployment.annotations.ExecutionTime.STATIC_INIT;

class QuarkusNotificationProcessor {

    protected SendConfig sendConfig;

    private static final String FEATURE = "quarkus-notification";

    @BuildStep
    FeatureBuildItem feature() {
        return new FeatureBuildItem(FEATURE);
    }

    @BuildStep
    @Record(STATIC_INIT)
    void loadDSmsSenderImpl(SenderRecorder recorder,
                            BuildProducer<ObjectSubstitutionBuildItem> substitutions) {
        // Register how to serialize SmsSenderImpl
        ObjectSubstitutionBuildItem.Holder<SmsSenderImpl, SmsSenderImplObjectSubstitution.SmsSenderSubstitutionProxy> holder = new ObjectSubstitutionBuildItem.Holder(
                SmsSenderImpl.class, SmsSenderImplObjectSubstitution.SmsSenderSubstitutionProxy.class, SmsSenderImplObjectSubstitution.class
        );
        ObjectSubstitutionBuildItem smsImplSustitution = new ObjectSubstitutionBuildItem(holder);
        substitutions.produce(smsImplSustitution);

    }

    @BuildStep
    @Record(STATIC_INIT)
    void registerNativeImageResources(BuildProducer<SpiInfoBuildItem> spiInfoBuildItemBuildProducer,
                                      RecorderContext recorderContext,
                                      SenderRecorder recorder,
                                      List<ObjectSubstitutionBuildItem> substitutionBuildItems) throws IOException {

        String service = "META-INF/services/" + Sender.class.getName();
        // read the implementation classes
        Collection<Class<? extends Sender>> implementationClasses = new LinkedHashSet<>();
        Set<String> implementations = ServiceUtil.classNamesNamedIn(Thread.currentThread().getContextClassLoader(),
                service);
        for (String implementation : implementations) {
            Optional<ObjectSubstitutionBuildItem> first = substitutionBuildItems.stream()
                    .filter(f -> f.getHolder() != null && f.getHolder().from.getName().equals(implementation))
                    .findFirst();
            if (first.isPresent()) {
                implementationClasses.add((Class<? extends Sender>) recorderContext.classProxy(first.get().getHolder().to.getName()));
            } else {
                implementationClasses.add((Class<? extends Sender>) recorderContext.classProxy(implementation));
            }
        }
        // produce a static-initializer with those classes
        List<Sender> services = recorder.registry(implementationClasses);
        spiInfoBuildItemBuildProducer.produce(new SpiInfoBuildItem(services));
    }

    @BuildStep
    @Record(ExecutionTime.RUNTIME_INIT)
    void processSend(SenderRecorder recorder, BeanContainerBuildItem beanContainerBuildItem, SpiInfoBuildItem spiInfoBuildItem) {
        recorder.sendAll(beanContainerBuildItem.getValue(), spiInfoBuildItem.getService(), sendConfig.from, sendConfig.to);
    }

}






























