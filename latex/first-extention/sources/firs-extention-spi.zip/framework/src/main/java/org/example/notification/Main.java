package org.example.notification;

public class Main {
    public static void main(String[] args) {
        String sender = "sender@gmail.com";
        String receiver = "receiver@gmail.com";
        MailSender mailSender = new MailSender();
        mailSender.send(sender, receiver);
    }
}
