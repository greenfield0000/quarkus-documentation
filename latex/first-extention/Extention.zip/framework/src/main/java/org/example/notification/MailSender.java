package org.example.notification;

/**
 * Класс для отправки майл сообщений
 */
public class MailSender {

    private String from;
    private String to;

    public MailSender() {
    }

    public MailSender(String from, String to) {
        this.from = from;
        this.to = to;
    }

    public void send(String from, String to) {
        System.out.println(String.format("Отправляю супер важную смс при поднятии контекста от %s адресату %s", from, to));
    }
}
