package org.example.quarkus.notification.producer;

import org.example.notification.MailSender;
import org.example.quarkus.notification.configuration.MailConfig;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

/**
 * Поставщик
 */
@ApplicationScoped
public class MailSenderProducer {

    private MailConfig mailConfig;

    @Produces
    public MailSender mailSender() {
        return new MailSender(mailConfig.from, mailConfig.to);
    }

    /**
     * Установка конфигурации
     *
     * @param mailConfig конфигурация
     */
    public void setMailConfig(MailConfig mailConfig) {
        this.mailConfig = mailConfig;
    }
}
