package org.example.quarkus.notification.configuration;


import io.quarkus.runtime.annotations.ConfigItem;
import io.quarkus.runtime.annotations.ConfigPhase;
import io.quarkus.runtime.annotations.ConfigRoot;

/**
 * Конфигурация для отправки
 */
@ConfigRoot(name = "mail", phase = ConfigPhase.BUILD_AND_RUN_TIME_FIXED)
public final class MailConfig {
    /**
     * Адрес отправителя
     */
    @ConfigItem
    public String from;
    /**
     * Адрес получателя
     */
    @ConfigItem
    public String to;
}