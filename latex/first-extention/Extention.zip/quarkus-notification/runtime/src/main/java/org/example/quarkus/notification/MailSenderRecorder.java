package org.example.quarkus.notification;

import io.quarkus.arc.runtime.BeanContainer;
import io.quarkus.arc.runtime.BeanContainerListener;
import io.quarkus.runtime.annotations.Recorder;
import org.example.notification.MailSender;
import org.example.quarkus.notification.configuration.MailConfig;
import org.example.quarkus.notification.producer.MailSenderProducer;

@Recorder
public class MailSenderRecorder {

    /**
     * Установка конфигурации
     *
     * @param mailConfig конфигурация
     * @return слушатель контейнера бинов
     */
    public BeanContainerListener setMailSenderConfig(MailConfig mailConfig) {
        return beanContainer -> {
            MailSenderProducer producer = beanContainer.instance(MailSenderProducer.class);
            producer.setMailConfig(mailConfig);
        };
    }

    /**
     * Отправка сообщения
     *
     * @param container контейнер
     * @param from      отправитель
     * @param to        получатель
     */
    public void send(BeanContainer container, String from, String to) {
        MailSender liquibase = container.instance(MailSender.class);
        liquibase.send(from, to);
    }

}
