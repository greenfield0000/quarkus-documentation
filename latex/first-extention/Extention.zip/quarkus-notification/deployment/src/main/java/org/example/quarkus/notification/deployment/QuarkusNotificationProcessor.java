package org.example.quarkus.notification.deployment;

import io.quarkus.arc.deployment.AdditionalBeanBuildItem;
import io.quarkus.arc.deployment.BeanContainerBuildItem;
import io.quarkus.arc.deployment.BeanContainerListenerBuildItem;
import io.quarkus.deployment.annotations.BuildProducer;
import io.quarkus.deployment.annotations.BuildStep;
import io.quarkus.deployment.annotations.ExecutionTime;
import io.quarkus.deployment.annotations.Record;
import io.quarkus.deployment.builditem.FeatureBuildItem;
import org.example.quarkus.notification.MailSenderRecorder;
import org.example.quarkus.notification.configuration.MailConfig;
import org.example.quarkus.notification.producer.MailSenderProducer;

class QuarkusNotificationProcessor {

    private MailConfig mailConfig;

    private static final String FEATURE = "quarkus-notification";

    @BuildStep
    FeatureBuildItem feature() {
        return new FeatureBuildItem(FEATURE);
    }

    @BuildStep
    @Record(ExecutionTime.STATIC_INIT)
    void build(MailSenderRecorder recorder,
               BuildProducer<AdditionalBeanBuildItem> additionalBeanProducer,
               BuildProducer<BeanContainerListenerBuildItem> containerListenerProducer) {

        AdditionalBeanBuildItem unremovableProducer = AdditionalBeanBuildItem.unremovableOf(MailSenderProducer.class);
        additionalBeanProducer.produce(unremovableProducer);

        containerListenerProducer.produce(
                new BeanContainerListenerBuildItem(recorder.setMailSenderConfig(mailConfig)));
    }

    @BuildStep
    @Record(ExecutionTime.RUNTIME_INIT)
    void processSend(MailSenderRecorder recorder, BeanContainerBuildItem beanContainer) {
        recorder.send(beanContainer.getValue(), mailConfig.from, mailConfig.to);
    }

}
